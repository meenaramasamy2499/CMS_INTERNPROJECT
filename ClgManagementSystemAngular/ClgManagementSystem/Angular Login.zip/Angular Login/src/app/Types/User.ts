export class  User  {

    constructor(public UserName:string,public Password:string, public UserType:string,public FirstName:string,public LastName:string) {}

}
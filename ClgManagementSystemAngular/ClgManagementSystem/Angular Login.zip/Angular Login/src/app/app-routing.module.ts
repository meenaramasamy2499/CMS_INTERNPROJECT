import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminComponent } from './admin/admin.component';
import { FacultyComponent } from './faculty/faculty.component';
import { HomeComponent } from './home/home.component';

import { ParentComponent } from './parent/parent.component';
import { StudentComponent } from './student/student.component';
import { UserloginComponent } from './userlogin/userlogin.component';

const routes: Routes = [
  {path:'UserLogin',component:UserloginComponent},
  {path:'Home',component:HomeComponent},
  {path:'Student',component:StudentComponent},
  {path:'Admin',component:AdminComponent},
  {path:'Faculty',component:FacultyComponent},
  {path:'Parent',component:ParentComponent},
 
  {path:'',redirectTo:'UserLogin', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

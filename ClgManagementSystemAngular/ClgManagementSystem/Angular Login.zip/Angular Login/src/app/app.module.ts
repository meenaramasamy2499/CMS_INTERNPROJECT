import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {HttpClientModule} from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { HomeComponent } from './home/home.component';
import { ParentComponent } from './parent/parent.component';
import { FacultyComponent } from './faculty/faculty.component';
import { AdminComponent } from './admin/admin.component';
import { StudentComponent } from './student/student.component';

import {  FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AuthService } from './auth.service';
import { UserloginComponent } from './userlogin/userlogin.component';

@NgModule({
  declarations: [
        AppComponent,
        UserloginComponent,
        HomeComponent,
        ParentComponent,
        FacultyComponent,
        AdminComponent,
        StudentComponent
       
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    AppRoutingModule,
    HttpClientModule
   
   
  ],
  providers: [AuthService],
  bootstrap: [AppComponent]
})
export class AppModule { }
